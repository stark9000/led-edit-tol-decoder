import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * TolPlayer - Java 8 Swing player for LED Edit *.tol project files.
 *
 * .tol layout:
 *   0  uint32 BE  frame count
 *   4  uint16 BE  dimension A (e.g. 10)
 *   6  uint16 BE  dimension B (e.g. 60)      pixels = A * B
 *   8  uint16 BE  unknown
 *   10 uint16 BE  unknown
 *   12 uint8      bytes per pixel (3)
 *   13 uint8      reserved
 *   14 frames: pixels * 3 bytes each, R,G,B, 7-bit values (0..127)
 */
public class TolPlayer extends JFrame {

    // ------------------------------------------------------------------ model
    static final class TolFile {
        final File file;
        final int frames, dimA, dimB, pixels, unk1, unk2;
        final byte[] data; // all frame bytes (already scaled to 8-bit)

        TolFile(File f) throws IOException {
            this.file = f;
            byte[] all = readAll(f);
            if (all.length < 14) throw new IOException("File too small");
            int fr = ((all[0] & 0xFF) << 24) | ((all[1] & 0xFF) << 16) | ((all[2] & 0xFF) << 8) | (all[3] & 0xFF);
            dimA = u16(all, 4);
            dimB = u16(all, 6);
            unk1 = u16(all, 8);
            unk2 = u16(all, 10);
            int bpp = all[12] & 0xFF;
            if (bpp != 3) throw new IOException("Unsupported bytes/pixel: " + bpp);
            pixels = dimA * dimB;
            if (pixels <= 0) throw new IOException("Bad dimensions " + dimA + "x" + dimB);
            int available = (all.length - 14) / (pixels * 3);
            frames = Math.min(fr, available);
            if (frames <= 0) throw new IOException("No frames");
            data = new byte[frames * pixels * 3];
            for (int i = 0; i < data.length; i++) {
                int v = all[14 + i] & 0x7F;
                data[i] = (byte) ((v << 1) | (v >> 6)); // 0..127 -> 0..255
            }
        }

        int rgb(int frame, int px) {
            int o = (frame * pixels + px) * 3;
            return ((data[o] & 0xFF) << 16) | ((data[o + 1] & 0xFF) << 8) | (data[o + 2] & 0xFF);
        }

        String name() { return file.getName(); }

        private static int u16(byte[] b, int o) { return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF); }

        private static byte[] readAll(File f) throws IOException {
            try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream((int) Math.max(16, f.length()));
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return bos.toByteArray();
            }
        }

        @Override public String toString() { return name(); }
    }

    enum Wiring { SINGLE_ROW("Single row"), RETURN_ROW("Return row (zig-zag)"),
        SINGLE_COLUMN("Single column"), RETURN_COLUMN("Return column (zig-zag)");
        final String label; Wiring(String l) { label = l; }
        @Override public String toString() { return label; } }

    enum Layout { GRID("Grid"), RINGS("Rings (circle)"), SPOKES("Spokes (wheel)"), STRIP("Single strip");
        final String label; Layout(String l) { label = l; }
        @Override public String toString() { return label; } }

    // ------------------------------------------------------------------ view
    static final class LedPanel extends JPanel {
        TolFile tol;
        int frame;
        Layout layout = Layout.RINGS;
        boolean swap, serpentine, reverse, glow = true;
        boolean flipGroups = true;   // LED Edit row 0 = outer rim, last row = hub
        int rotateSteps = 0;         // rotate the wheel by N pixel positions
        String colorOrder = "RGB";  // how file bytes map to displayed R,G,B
        int innerPct = 30;
        float ledScale = 0.8f;

        LedPanel() {
            setBackground(new Color(12, 12, 16));
            setPreferredSize(new Dimension(760, 620));
        }

        /** file bytes are b0,b1,b2; order string says which display channel each byte is. */
        static int reorder(int c, String order) {
            if ("RGB".equals(order)) return c;
            int[] in = {(c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF};
            int r = 0, g = 0, b = 0;
            for (int k = 0; k < 3; k++) {
                char ch = order.charAt(k);
                if (ch == 'R') r = in[k]; else if (ch == 'G') g = in[k]; else b = in[k];
            }
            return (r << 16) | (g << 8) | b;
        }

        // ---------------- wiring ----------------
        Wiring wiring = Wiring.SINGLE_ROW;
        boolean startLastRow = false;   // false = start at hub / top row
        boolean startLastCol = false;   // false = start at spoke 0 going CW / left column going right
        boolean showPath = false;
        boolean simulateRaw = false;

        // per-pixel geometry, rebuilt on every paint
        private int nRows, nCols;
        private int[] rowOf, colOf;
        private double[] px, py, pd;

        /** Compute display row/col (ring/spoke for wheels) and screen position for every file pixel. */
        void computeGeometry(int w, int h) {
            int n = tol.pixels;
            if (rowOf == null || rowOf.length != n) {
                rowOf = new int[n]; colOf = new int[n]; px = new double[n]; py = new double[n]; pd = new double[n];
            }
            int groups = swap ? tol.dimB : tol.dimA;
            int per = swap ? tol.dimA : tol.dimB;
            int pad = 20;
            int sCols = (int) Math.ceil(Math.sqrt(n * (double) w / h));
            int sRows = (int) Math.ceil(n / (double) sCols);
            switch (layout) {
                case RINGS: nRows = groups; nCols = per; break;   // row = ring, col = spoke
                case SPOKES: nRows = per; nCols = groups; break;  // row = ring (radial), col = spoke
                case GRID: nRows = groups; nCols = per; break;
                default: nRows = sRows; nCols = sCols; break;
            }
            for (int i = 0; i < n; i++) {
                int gIdx = i / per, pos = i % per;
                if (flipGroups) gIdx = groups - 1 - gIdx;
                if (serpentine && (gIdx & 1) == 1) pos = per - 1 - pos;
                if (reverse) pos = per - 1 - pos;
                if (layout == Layout.RINGS) pos = Math.floorMod(pos + rotateSteps, per);
                if (layout == Layout.SPOKES) gIdx = Math.floorMod(gIdx + rotateSteps, groups);
                double x, y, d;
                switch (layout) {
                    case GRID: {
                        double cell = Math.min((w - 2.0 * pad) / per, (h - 2.0 * pad) / groups);
                        double ox = (w - cell * per) / 2, oy = (h - cell * groups) / 2;
                        x = ox + (pos + 0.5) * cell; y = oy + (gIdx + 0.5) * cell; d = cell * ledScale;
                        rowOf[i] = gIdx; colOf[i] = pos;
                        break;
                    }
                    case STRIP: {
                        double cell = Math.min((w - 2.0 * pad) / sCols, (h - 2.0 * pad) / sRows);
                        double ox = (w - cell * sCols) / 2, oy = (h - cell * sRows) / 2;
                        int r = i / sCols, c = i % sCols;
                        x = ox + (c + 0.5) * cell; y = oy + (r + 0.5) * cell; d = cell * ledScale;
                        rowOf[i] = r; colOf[i] = c;
                        break;
                    }
                    case RINGS: {
                        double R = Math.min(w, h) / 2.0 - pad, r0 = R * innerPct / 100.0;
                        double step = groups > 1 ? (R - r0) / (groups - 1) : 0;
                        double rad = r0 + gIdx * step;
                        double ang = -Math.PI / 2 + 2 * Math.PI * pos / per;
                        x = w / 2.0 + rad * Math.cos(ang); y = h / 2.0 + rad * Math.sin(ang);
                        double arc = 2 * Math.PI * Math.max(rad, 1) / per;
                        d = Math.min(arc, step > 0 ? step : arc) * ledScale;
                        rowOf[i] = gIdx; colOf[i] = pos;
                        break;
                    }
                    default: { // SPOKES
                        double R = Math.min(w, h) / 2.0 - pad, r0 = R * innerPct / 100.0;
                        double step = per > 1 ? (R - r0) / (per - 1) : 0;
                        double rad = r0 + pos * step;
                        double ang = -Math.PI / 2 + 2 * Math.PI * gIdx / groups;
                        x = w / 2.0 + rad * Math.cos(ang); y = h / 2.0 + rad * Math.sin(ang);
                        double arc = 2 * Math.PI * Math.max(rad, 1) / groups;
                        d = Math.min(arc, step > 0 ? step : arc) * ledScale;
                        rowOf[i] = pos; colOf[i] = gIdx;
                        break;
                    }
                }
                px[i] = x; py[i] = y; pd[i] = Math.max(d, 2);
            }
        }

        /**
         * chain[k] = file pixel index that the k-th LED on the physical strip must show.
         * Built from the current layout + wiring settings.
         */
        int[] buildChainMap() {
            if (tol == null) return null;
            computeGeometry(Math.max(getWidth(), 100), Math.max(getHeight(), 100));
            int n = tol.pixels;
            int[] rc = new int[nRows * nCols];
            Arrays.fill(rc, -1);
            for (int i = 0; i < n; i++) rc[rowOf[i] * nCols + colOf[i]] = i;
            int[] chain = new int[n];
            int k = 0;
            int total = nRows * nCols;
            for (int s = 0; s < total && k < n; s++) {
                int r, c;
                switch (wiring) {
                    case SINGLE_ROW:    r = s / nCols; c = s % nCols; break;
                    case RETURN_ROW:    r = s / nCols; c = s % nCols; if ((r & 1) == 1) c = nCols - 1 - c; break;
                    case SINGLE_COLUMN: c = s / nRows; r = s % nRows; break;
                    default:            c = s / nRows; r = s % nRows; if ((c & 1) == 1) r = nRows - 1 - r; break;
                }
                if (startLastRow) r = nRows - 1 - r;
                if (startLastCol) c = nCols - 1 - c;
                int idx = rc[r * nCols + c];
                if (idx >= 0) chain[k++] = idx;   // STRIP layout may have empty cells at the end
            }
            return chain;
        }

        @Override protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (tol == null) {
                g.setColor(new Color(120, 120, 130));
                g.setFont(getFont().deriveFont(16f));
                String s = "Open or drop .tol files to start";
                FontMetrics fm = g.getFontMetrics();
                g.drawString(s, (getWidth() - fm.stringWidth(s)) / 2, getHeight() / 2);
                g.dispose();
                return;
            }
            int n = tol.pixels;
            int[] chain = (showPath || simulateRaw) ? buildChainMap() : null;
            computeGeometry(getWidth(), getHeight());

            // colour source per location: normally file pixel i; in "raw" mode LED k (at location chain[k]) shows file pixel k
            int[] src = null;
            if (simulateRaw) {
                src = new int[n];
                for (int k = 0; k < n; k++) src[chain[k]] = k;
            }
            for (int i = 0; i < n; i++) {
                double x = px[i], y = py[i], d = pd[i];
                int c = reorder(tol.rgb(frame, src == null ? i : src[i]), colorOrder);
                if (c == 0) {
                    g.setColor(new Color(34, 34, 40));
                    g.fill(new Ellipse2D.Double(x - d / 2, y - d / 2, d, d));
                } else {
                    Color col = new Color(c);
                    if (glow) {
                        g.setColor(new Color(col.getRed(), col.getGreen(), col.getBlue(), 55));
                        double gd = d * 1.9;
                        g.fill(new Ellipse2D.Double(x - gd / 2, y - gd / 2, gd, gd));
                    }
                    g.setColor(col);
                    g.fill(new Ellipse2D.Double(x - d / 2, y - d / 2, d, d));
                }
            }
            if (showPath && chain != null) {
                g.setStroke(new BasicStroke(1.3f));
                g.setColor(new Color(255, 255, 255, 140));
                for (int k = 1; k < n; k++) {
                    int a = chain[k - 1], b = chain[k];
                    g.draw(new java.awt.geom.Line2D.Double(px[a], py[a], px[b], py[b]));
                }
                int s0 = chain[0], s1 = chain[n - 1];
                double r = Math.max(pd[s0], 8);
                g.setColor(new Color(40, 255, 90));
                g.setStroke(new BasicStroke(3f));
                g.draw(new Ellipse2D.Double(px[s0] - r, py[s0] - r, 2 * r, 2 * r));
                g.setColor(new Color(255, 60, 60));
                g.draw(new Ellipse2D.Double(px[s1] - r, py[s1] - r, 2 * r, 2 * r));
                g.setFont(getFont().deriveFont(Font.BOLD, 12f));
                g.setColor(new Color(40, 255, 90));
                g.drawString("IN (LED 0)", (float) (px[s0] + r + 3), (float) (py[s0] + 4));
                g.setColor(new Color(255, 90, 90));
                g.drawString("END", (float) (px[s1] + r + 3), (float) (py[s1] + 4));
            }
            if (simulateRaw) {
                g.setColor(new Color(255, 200, 60));
                g.setFont(getFont().deriveFont(Font.BOLD, 13f));
                g.drawString("RAW / UNMAPPED preview: what the strip shows if file data is sent without remapping", 10, 18);
            }
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ UI
    private final DefaultListModel<TolFile> listModel = new DefaultListModel<>();
    private final JList<TolFile> list = new JList<>(listModel);
    private final LedPanel view = new LedPanel();
    private final JSlider seek = new JSlider(0, 0, 0);
    private final JLabel status = new JLabel(" ");
    private final JLabel info = new JLabel(" ");
    private final JButton playBtn = new JButton("▶ Play");
    private final JSpinner fpsSpin = new JSpinner(new SpinnerNumberModel(25, 1, 120, 1));
    private final JCheckBox loopFile = new JCheckBox("Loop file", false);
    private final JCheckBox autoNext = new JCheckBox("Auto next", true);
    private final Timer timer;
    private boolean seekAdjusting;
    private File lastDir;

    public TolPlayer() {
        super("LED Edit .tol Player");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        timer = new Timer(40, e -> step(1, true));
        timer.setCoalesce(true);

        // ---- playlist
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) load(list.getSelectedValue()); });
        JScrollPane listScroll = new JScrollPane(list);
        listScroll.setPreferredSize(new Dimension(230, 400));
        JButton addFiles = new JButton("Add files...");
        JButton addFolder = new JButton("Add folder...");
        JButton remove = new JButton("Remove");
        JButton clear = new JButton("Clear");
        addFiles.addActionListener(e -> chooseFiles(false));
        addFolder.addActionListener(e -> chooseFiles(true));
        remove.addActionListener(e -> { int i = list.getSelectedIndex(); if (i >= 0) { listModel.remove(i); if (listModel.isEmpty()) load(null); } });
        clear.addActionListener(e -> { listModel.clear(); load(null); });
        JPanel listBtns = new JPanel(new GridLayout(2, 2, 4, 4));
        listBtns.add(addFiles); listBtns.add(addFolder); listBtns.add(remove); listBtns.add(clear);
        JPanel left = new JPanel(new BorderLayout(4, 4));
        left.setBorder(new EmptyBorder(6, 6, 6, 0));
        left.add(new JLabel("Playlist"), BorderLayout.NORTH);
        left.add(listScroll, BorderLayout.CENTER);
        left.add(listBtns, BorderLayout.SOUTH);

        // ---- layout options
        JComboBox<Layout> layoutBox = new JComboBox<>(Layout.values());
        layoutBox.setSelectedItem(view.layout);
        layoutBox.addActionListener(e -> { view.layout = (Layout) layoutBox.getSelectedItem(); view.repaint(); });
        JCheckBox swap = new JCheckBox("Swap A/B");
        swap.addActionListener(e -> { view.swap = swap.isSelected(); view.repaint(); });
        JCheckBox serp = new JCheckBox("Serpentine");
        serp.addActionListener(e -> { view.serpentine = serp.isSelected(); view.repaint(); });
        JCheckBox rev = new JCheckBox("Reverse");
        rev.addActionListener(e -> { view.reverse = rev.isSelected(); view.repaint(); });
        JCheckBox flip = new JCheckBox("Hub\u2194Rim flip", view.flipGroups);
        flip.setToolTipText("LED Edit stores the outer ring first; keep ON for wheels");
        flip.addActionListener(e -> { view.flipGroups = flip.isSelected(); view.repaint(); });
        JComboBox<String> order = new JComboBox<>(new String[]{"RGB", "GRB", "BRG", "RBG", "GBR", "BGR"});
        order.addActionListener(e -> { view.colorOrder = (String) order.getSelectedItem(); view.repaint(); });
        JSpinner rot = new JSpinner(new SpinnerNumberModel(0, -999, 999, 1));
        rot.setToolTipText("Rotate wheel by N positions");
        rot.addChangeListener(e -> { view.rotateSteps = (Integer) rot.getValue(); view.repaint(); });
        JCheckBox glow = new JCheckBox("Glow", true);
        glow.addActionListener(e -> { view.glow = glow.isSelected(); view.repaint(); });
        JSlider inner = new JSlider(0, 80, view.innerPct);
        inner.setPreferredSize(new Dimension(90, 22));
        inner.addChangeListener(e -> { view.innerPct = inner.getValue(); view.repaint(); });
        JSlider size = new JSlider(20, 100, (int) (view.ledScale * 100));
        size.setPreferredSize(new Dimension(90, 22));
        size.addChangeListener(e -> { view.ledScale = size.getValue() / 100f; view.repaint(); });

        JPanel opts = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        opts.add(new JLabel("Layout:")); opts.add(layoutBox);
        opts.add(flip); opts.add(swap); opts.add(serp); opts.add(rev); opts.add(glow);
        opts.add(new JLabel("Colour:")); opts.add(order);
        opts.add(new JLabel("Rotate:")); opts.add(rot);
        opts.add(new JLabel("Inner:")); opts.add(inner);
        opts.add(new JLabel("LED size:")); opts.add(size);

        // ---- transport
        JButton first = new JButton("⏮");
        JButton prev = new JButton("◀|");
        JButton next = new JButton("|▶");
        JButton stop = new JButton("■ Stop");
        JButton png = new JButton("Save PNG");
        first.setToolTipText("First frame");
        prev.setToolTipText("Previous frame");
        next.setToolTipText("Next frame");
        playBtn.addActionListener(e -> togglePlay());
        stop.addActionListener(e -> { pause(); setFrame(0); });
        first.addActionListener(e -> setFrame(0));
        prev.addActionListener(e -> { pause(); step(-1, false); });
        next.addActionListener(e -> { pause(); step(1, false); });
        png.addActionListener(e -> savePng());
        fpsSpin.addChangeListener((ChangeEvent e) -> timer.setDelay(Math.max(1, 1000 / (Integer) fpsSpin.getValue())));
        seek.addChangeListener(e -> { if (!seekAdjusting && view.tol != null) { view.frame = seek.getValue(); updateStatus(); view.repaint(); } });

        JPanel transport = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        transport.add(first); transport.add(prev); transport.add(playBtn); transport.add(stop); transport.add(next);
        transport.add(new JLabel("FPS:")); transport.add(fpsSpin);
        transport.add(loopFile); transport.add(autoNext); transport.add(png);

        JPanel bottom = new JPanel(new BorderLayout(4, 2));
        bottom.setBorder(new EmptyBorder(4, 6, 6, 6));
        bottom.add(seek, BorderLayout.NORTH);
        bottom.add(transport, BorderLayout.CENTER);
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.add(status, BorderLayout.WEST);
        statusBar.add(info, BorderLayout.EAST);
        bottom.add(statusBar, BorderLayout.SOUTH);

        // ---- wiring options
        JComboBox<Wiring> wiringBox = new JComboBox<>(Wiring.values());
        wiringBox.setToolTipText("<html>Physical chain order. For wheels: ROW = ring (around), COLUMN = spoke (radial).</html>");
        wiringBox.addActionListener(e -> { view.wiring = (Wiring) wiringBox.getSelectedItem(); view.repaint(); });
        JComboBox<String> startBox = new JComboBox<>(new String[]{"Hub / top row", "Rim / bottom row"});
        startBox.setToolTipText("Which ring (row) LED 0 is on");
        startBox.addActionListener(e -> { view.startLastRow = startBox.getSelectedIndex() == 1; view.repaint(); });
        JComboBox<String> dirBox = new JComboBox<>(new String[]{"CW / left\u2192right", "CCW / right\u2190left"});
        dirBox.setToolTipText("Which way LED 0 moves around the wheel (or across the grid)");
        dirBox.addActionListener(e -> { view.startLastCol = dirBox.getSelectedIndex() == 1; view.repaint(); });
        JCheckBox pathBox = new JCheckBox("Show path");
        pathBox.addActionListener(e -> { view.showPath = pathBox.isSelected(); view.repaint(); });
        JCheckBox rawBox = new JCheckBox("Raw preview");
        rawBox.setToolTipText("Show what the LEDs display if the file is sent to this wiring WITHOUT remapping");
        rawBox.addActionListener(e -> { view.simulateRaw = rawBox.isSelected(); view.repaint(); });
        JButton exportTol = new JButton("Export wired .tol...");
        exportTol.setToolTipText("Re-order every playlist file into chain order, so the Arduino can play it straight");
        exportTol.addActionListener(e -> exportWired());
        JButton exportMap = new JButton("Export map .h...");
        exportMap.setToolTipText("Write wiring_map.h lookup table for the Arduino sketch");
        exportMap.addActionListener(e -> exportMapHeader());

        JPanel wiringRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        wiringRow.add(new JLabel("Wiring:")); wiringRow.add(wiringBox);
        wiringRow.add(new JLabel("Start:")); wiringRow.add(startBox);
        wiringRow.add(new JLabel("Dir:")); wiringRow.add(dirBox);
        wiringRow.add(pathBox); wiringRow.add(rawBox);
        wiringRow.add(exportTol); wiringRow.add(exportMap);

        JPanel north = new JPanel();
        north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS));
        opts.setAlignmentX(0f); wiringRow.setAlignmentX(0f);
        north.add(opts); north.add(wiringRow);

        JPanel center = new JPanel(new BorderLayout());
        center.add(north, BorderLayout.NORTH);
        center.add(view, BorderLayout.CENTER);
        center.add(bottom, BorderLayout.SOUTH);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(left, BorderLayout.WEST);
        getContentPane().add(center, BorderLayout.CENTER);

        installDragAndDrop();
        installKeys();
        timer.setDelay(1000 / 25);
        pack();
        setLocationRelativeTo(null);
    }

    // ------------------------------------------------------------------ actions
    private void chooseFiles(boolean folder) {
        JFileChooser fc = new JFileChooser(lastDir);
        if (folder) {
            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        } else {
            fc.setMultiSelectionEnabled(true);
            fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("LED Edit files (*.tol)", "tol"));
        }
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File[] picked = folder ? new File[]{fc.getSelectedFile()} : fc.getSelectedFiles();
        lastDir = picked.length > 0 ? picked[0].getParentFile() : lastDir;
        addFiles(Arrays.asList(picked));
    }

    private void addFiles(List<File> files) {
        List<File> tols = new ArrayList<>();
        for (File f : files) collect(f, tols);
        tols.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        int firstNew = listModel.size();
        StringBuilder errors = new StringBuilder();
        for (File f : tols) {
            try {
                listModel.addElement(new TolFile(f));
            } catch (IOException | OutOfMemoryError ex) {
                errors.append(f.getName()).append(": ").append(ex.getMessage()).append('\n');
            }
        }
        if (errors.length() > 0) JOptionPane.showMessageDialog(this, errors.toString(), "Some files could not be loaded", JOptionPane.WARNING_MESSAGE);
        if (list.getSelectedIndex() < 0 && listModel.size() > firstNew) list.setSelectedIndex(firstNew);
        if (tols.isEmpty()) status.setText("No .tol files found");
    }

    private static void collect(File f, List<File> out) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) if (k.isFile()) collect(k, out);
        } else if (f.getName().toLowerCase().endsWith(".tol")) {
            out.add(f);
        }
    }

    private void load(TolFile t) {
        view.tol = t;
        view.frame = 0;
        seekAdjusting = true;
        seek.setMaximum(t == null ? 0 : t.frames - 1);
        seek.setValue(0);
        seekAdjusting = false;
        if (t == null) pause();
        info.setText(t == null ? " " : String.format("%d x %d = %d px  |  %d frames  |  hdr %d, %d  ",
                t.dimA, t.dimB, t.pixels, t.frames, t.unk1, t.unk2));
        updateStatus();
        view.repaint();
    }

    private void togglePlay() {
        if (view.tol == null) return;
        if (timer.isRunning()) pause(); else { timer.start(); playBtn.setText("❚❚ Pause"); }
    }

    private void pause() { timer.stop(); playBtn.setText("▶ Play"); }

    private void step(int dir, boolean playing) {
        TolFile t = view.tol;
        if (t == null) return;
        int f = view.frame + dir;
        if (f >= t.frames) {
            if (playing && !loopFile.isSelected() && autoNext.isSelected() && listModel.size() > 1) {
                list.setSelectedIndex((list.getSelectedIndex() + 1) % listModel.size());
                return;
            }
            f = 0;
        } else if (f < 0) {
            f = t.frames - 1;
        }
        setFrame(f);
    }

    private void setFrame(int f) {
        if (view.tol == null) return;
        view.frame = f;
        seekAdjusting = true;
        seek.setValue(f);
        seekAdjusting = false;
        updateStatus();
        view.repaint();
    }

    private void updateStatus() {
        TolFile t = view.tol;
        if (t == null) { status.setText(" Ready"); return; }
        int fps = (Integer) fpsSpin.getValue();
        status.setText(String.format(" %s   frame %d / %d   (%.1f s / %.1f s)", t.name(), view.frame + 1, t.frames,
                view.frame / (double) fps, t.frames / (double) fps));
    }

    private void savePng() {
        if (view.tol == null) return;
        JFileChooser fc = new JFileChooser(lastDir);
        String base = view.tol.name().replaceAll("\\.tol$", "");
        fc.setSelectedFile(new File(lastDir, base + "_f" + (view.frame + 1) + ".png"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        BufferedImage img = new BufferedImage(view.getWidth(), view.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        view.paint(g);
        g.dispose();
        try {
            javax.imageio.ImageIO.write(img, "png", fc.getSelectedFile());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Save failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String wiringDescription() {
        return String.format("layout=%s wiring=%s start=%s dir=%s flip=%s swap=%s rotate=%d",
                view.layout.name(), view.wiring.name(), view.startLastRow ? "RIM/BOTTOM" : "HUB/TOP",
                view.startLastCol ? "CCW" : "CW", view.flipGroups, view.swap, view.rotateSteps);
    }

    private void exportWired() {
        if (listModel.isEmpty()) return;
        int[] chain = view.buildChainMap();
        JFileChooser fc = new JFileChooser(lastDir);
        fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fc.setDialogTitle("Folder for wired .tol files (all playlist files)");
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        File dir = fc.getSelectedFile();
        int ok = 0;
        StringBuilder err = new StringBuilder();
        for (int i = 0; i < listModel.size(); i++) {
            TolFile t = listModel.get(i);
            if (t.pixels != chain.length) { err.append(t.name()).append(": different pixel count, skipped\n"); continue; }
            File out = new File(dir, t.name());
            if (out.getAbsoluteFile().equals(t.file.getAbsoluteFile())) { err.append(t.name()).append(": would overwrite source, skipped\n"); continue; }
            try {
                writeWired(t, chain, out);
                ok++;
            } catch (IOException ex) {
                err.append(t.name()).append(": ").append(ex.getMessage()).append('\n');
            }
        }
        JOptionPane.showMessageDialog(this, ok + " file(s) written to\n" + dir + "\n\n" + wiringDescription()
                + (err.length() > 0 ? "\n\n" + err : ""), "Export wired .tol", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Same .tol format, but pixel k of every frame = original pixel chain[k] (original 7-bit values kept). */
    static void writeWired(TolFile t, int[] chain, File out) throws IOException {
        byte[] hdr = new byte[14];
        int frameBytes = t.pixels * 3;
        byte[] in = new byte[frameBytes], o = new byte[frameBytes];
        try (DataInputStream src = new DataInputStream(new BufferedInputStream(new FileInputStream(t.file)));
             OutputStream dst = new BufferedOutputStream(new FileOutputStream(out))) {
            src.readFully(hdr);
            hdr[0] = (byte) (t.frames >>> 24); hdr[1] = (byte) (t.frames >>> 16);
            hdr[2] = (byte) (t.frames >>> 8);  hdr[3] = (byte) t.frames;
            dst.write(hdr);
            for (int f = 0; f < t.frames; f++) {
                src.readFully(in);
                for (int k = 0; k < chain.length; k++) {
                    int s = chain[k] * 3, d = k * 3;
                    o[d] = in[s]; o[d + 1] = in[s + 1]; o[d + 2] = in[s + 2];
                }
                dst.write(o);
            }
        }
    }

    private void exportMapHeader() {
        int[] chain = view.buildChainMap();
        if (chain == null) return;
        JFileChooser fc = new JFileChooser(lastDir);
        fc.setSelectedFile(new File(lastDir, "wiring_map.h"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        StringBuilder sb = new StringBuilder();
        sb.append("// Generated by TolPlayer\n// ").append(wiringDescription()).append('\n');
        sb.append("// WIRING_MAP[k] = pixel index in the .tol frame that physical LED k must show\n");
        sb.append("#pragma once\n#include <Arduino.h>\n\n");
        sb.append("#define WIRING_MAP_LEN ").append(chain.length).append("\n");
        sb.append("const uint16_t WIRING_MAP[WIRING_MAP_LEN] PROGMEM = {\n");
        for (int k = 0; k < chain.length; k++) {
            if (k % 16 == 0) sb.append("  ");
            sb.append(chain[k]).append(k == chain.length - 1 ? "" : ",");
            sb.append(k % 16 == 15 || k == chain.length - 1 ? "\n" : " ");
        }
        sb.append("};\n");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(fc.getSelectedFile()), "UTF-8")) {
            w.write(sb.toString());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Save failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void installDragAndDrop() {
        setTransferHandler(new TransferHandler() {
            @Override public boolean canImport(TransferSupport s) { return s.isDataFlavorSupported(DataFlavor.javaFileListFlavor); }
            @SuppressWarnings("unchecked")
            @Override public boolean importData(TransferSupport s) {
                try {
                    addFiles((List<File>) s.getTransferable().getTransferData(DataFlavor.javaFileListFlavor));
                    return true;
                } catch (Exception ex) { return false; }
            }
        });
        list.setTransferHandler(getTransferHandler());
        view.setTransferHandler(getTransferHandler());
    }

    private void installKeys() {
        JRootPane rp = getRootPane();
        InputMap im = rp.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = rp.getActionMap();
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "play");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "next");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "prev");
        am.put("play", new AbstractAction() { public void actionPerformed(ActionEvent e) { togglePlay(); } });
        am.put("next", new AbstractAction() { public void actionPerformed(ActionEvent e) { pause(); step(1, false); } });
        am.put("prev", new AbstractAction() { public void actionPerformed(ActionEvent e) { pause(); step(-1, false); } });
    }

    // ------------------------------------------------------------------ main
    public static void main(String[] args) {
        // headless render test: TolPlayer --render file.tol frame layout out.png
        if (args.length >= 5 && "--render".equals(args[0])) {
            try {
                LedPanel p = new LedPanel();
                p.tol = new TolFile(new File(args[1]));
                p.frame = Integer.parseInt(args[2]);
                p.layout = Layout.valueOf(args[3]);
                if (args.length >= 10) {
                    p.wiring = Wiring.valueOf(args[5]);
                    p.startLastRow = Boolean.parseBoolean(args[6]);
                    p.startLastCol = Boolean.parseBoolean(args[7]);
                    p.showPath = Boolean.parseBoolean(args[8]);
                    p.simulateRaw = Boolean.parseBoolean(args[9]);
                }
                p.setSize(640, 640);
                BufferedImage img = new BufferedImage(640, 640, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = img.createGraphics();
                p.paint(g);
                g.dispose();
                javax.imageio.ImageIO.write(img, "png", new File(args[4]));
            } catch (Exception ex) { ex.printStackTrace(); System.exit(1); }
            return;
        }
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) { }
        SwingUtilities.invokeLater(() -> {
            TolPlayer p = new TolPlayer();
            List<File> files = new ArrayList<>();
            for (String a : args) files.add(new File(a));
            if (!files.isEmpty()) p.addFiles(files);
            p.setVisible(true);
        });
    }
}
