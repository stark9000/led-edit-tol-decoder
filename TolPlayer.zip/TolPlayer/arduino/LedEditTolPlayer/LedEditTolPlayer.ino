/*
  LedEditTolPlayer.ino
  Plays LED Edit project files (*.tol) straight from an SD card onto WS2811/WS2812 pixels.

  .tol layout (reverse-engineered from LED Edit "Circle" set):
    offset 0  : uint32 BE  frame count
    offset 4  : uint16 BE  dimension A   (e.g. 10)
    offset 6  : uint16 BE  dimension B   (e.g. 60)   -> pixels = A * B
    offset 8  : uint16 BE  unknown (0x0023)
    offset 10 : uint16 BE  unknown (0x0016)
    offset 12 : uint8      bytes per pixel (3)
    offset 13 : uint8      reserved
    offset 14 : frames, each = pixels * 3 bytes, R,G,B order, 7-bit values (0..127)

  Board: ESP32 recommended (Arduino Mega 2560 also works; Uno/Nano do NOT have enough RAM
  for 600 pixels + SD buffer).
  Libraries: FastLED, SD (built-in).
  SD card: FAT32, copy the .tol files to the root folder.
*/

#include <SPI.h>
#include <SD.h>
#include <FastLED.h>

// ---------------- user settings ----------------
#define DATA_PIN        5          // pixel data pin (ESP32: 5 is fine; Mega: any digital pin)
#define SD_CS_PIN       4          // SD card chip-select (ESP32 default VSPI: SCK18 MISO19 MOSI23)
#define LED_TYPE        WS2811
#define COLOR_ORDER     RGB        // change to GRB for most WS2812B strips
#define MAX_LEDS        600        // must be >= A*B of your files
#define FRAME_MS        40         // 40 ms = 25 fps; adjust to match LED Edit speed
#define BRIGHTNESS      255        // global brightness 0..255
#define LOOPS_PER_FILE  3          // how many times each file repeats before the next one

// Wiring: two ways to match your physical LED chain
//  A) In TolPlayer use "Export wired .tol..." and copy those files to the SD card -> keep USE_WIRING_MAP 0
//  B) Copy the original .tol files, use "Export map .h..." and put wiring_map.h next to this sketch -> USE_WIRING_MAP 1
#define USE_WIRING_MAP  0
// ------------------------------------------------

#if USE_WIRING_MAP
  #include "wiring_map.h"
  static uint8_t frameBuf[MAX_LEDS * 3];
#endif

CRGB leds[MAX_LEDS];

struct TolHeader {
  uint32_t frames;
  uint16_t dimA, dimB;
  uint8_t  bpp;
  uint16_t pixels;
};

static uint32_t be32(const uint8_t *p) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static uint16_t be16(const uint8_t *p) { return ((uint16_t)p[0] << 8) | p[1]; }

static bool hasTolExt(const char *name) {
  size_t n = strlen(name);
  if (n < 4) return false;
  const char *e = name + n - 4;
  return e[0] == '.' && (e[1] | 0x20) == 't' && (e[2] | 0x20) == 'o' && (e[3] | 0x20) == 'l';
}

static bool readHeader(File &f, TolHeader &h) {
  uint8_t b[14];
  if (f.read(b, 14) != 14) return false;
  h.frames = be32(b);
  h.dimA   = be16(b + 4);
  h.dimB   = be16(b + 6);
  h.bpp    = b[12];
  h.pixels = (uint16_t)((uint32_t)h.dimA * h.dimB);
  if (h.bpp != 3 || h.pixels == 0 || h.frames == 0) return false;
  // sanity: file size must match
  uint32_t expected = 14UL + (uint32_t)h.frames * h.pixels * 3UL;
  if (f.size() < expected) {
    h.frames = (f.size() - 14UL) / ((uint32_t)h.pixels * 3UL);
  }
  return h.frames > 0;
}

static void playFile(File &f) {
  TolHeader h;
  if (!readHeader(f, h)) {
    Serial.println(F("  bad header, skipped"));
    return;
  }
  uint16_t shown = min<uint16_t>(h.pixels, MAX_LEDS);
  uint32_t frameBytes = (uint32_t)h.pixels * 3UL;
  uint32_t skipBytes  = frameBytes - (uint32_t)shown * 3UL;

  Serial.print(F("  frames=")); Serial.print(h.frames);
  Serial.print(F("  size="));   Serial.print(h.dimA);
  Serial.print('x');            Serial.print(h.dimB);
  Serial.print(F(" = "));       Serial.print(h.pixels); Serial.println(F(" px"));

  for (uint8_t loop = 0; loop < LOOPS_PER_FILE; loop++) {
    f.seek(14);
    uint32_t next = millis();
    for (uint32_t fr = 0; fr < h.frames; fr++) {
#if USE_WIRING_MAP
      if (f.read(frameBuf, shown * 3) != (int)(shown * 3)) return;
      if (skipBytes) f.seek(f.position() + skipBytes);
      uint16_t mapped = min<uint16_t>(shown, WIRING_MAP_LEN);
      for (uint16_t k = 0; k < mapped; k++) {
        uint16_t src = pgm_read_word(&WIRING_MAP[k]);
        if (src >= shown) { leds[k] = CRGB::Black; continue; }
        const uint8_t *c = &frameBuf[src * 3];
        leds[k].r = (c[0] << 1) | (c[0] >> 6);   // 7-bit (0..127) -> 8-bit (0..255)
        leds[k].g = (c[1] << 1) | (c[1] >> 6);
        leds[k].b = (c[2] << 1) | (c[2] >> 6);
      }
#else
      // CRGB is laid out r,g,b in memory, so read straight into the buffer
      if (f.read((uint8_t *)leds, shown * 3) != (int)(shown * 3)) return;
      if (skipBytes) f.seek(f.position() + skipBytes);

      // 7-bit (0..127) -> 8-bit (0..255)
      uint8_t *p = (uint8_t *)leds;
      for (uint16_t i = 0; i < shown * 3; i++) p[i] = (p[i] << 1) | (p[i] >> 6);
#endif

      while ((int32_t)(millis() - next) < 0) { /* wait */ }
      FastLED.show();
      next += FRAME_MS;
    }
  }
}

void setup() {
  Serial.begin(115200);
  FastLED.addLeds<LED_TYPE, DATA_PIN, COLOR_ORDER>(leds, MAX_LEDS);
  FastLED.setBrightness(BRIGHTNESS);
  FastLED.clear(true);

  while (!SD.begin(SD_CS_PIN)) {
    Serial.println(F("SD init failed, retrying..."));
    delay(1000);
  }
  Serial.println(F("SD ready"));
}

void loop() {
  File root = SD.open("/");
  bool any = false;
  while (true) {
    File f = root.openNextFile();
    if (!f) break;
    if (!f.isDirectory() && hasTolExt(f.name())) {
      any = true;
      Serial.print(F("Playing: "));
      Serial.println(f.name());
      playFile(f);
    }
    f.close();
  }
  root.close();
  if (!any) {
    Serial.println(F("No .tol files on SD card"));
    delay(2000);
  }
}
